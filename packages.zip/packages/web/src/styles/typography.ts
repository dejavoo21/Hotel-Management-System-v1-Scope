export const KPI_VALUE_CLASS = 'text-[26px] font-semibold leading-tight tracking-tight text-slate-900';
export const KPI_VALUE_CLASS_SM = 'text-[22px] font-semibold leading-tight tracking-tight text-slate-900';
export const CARD_TITLE_CLASS = 'text-lg font-semibold text-slate-900';
export const CARD_SUBTITLE_CLASS = 'text-sm font-medium text-slate-500';
export const PAGE_TITLE_CLASS = 'text-2xl font-bold tracking-tight text-slate-900';
