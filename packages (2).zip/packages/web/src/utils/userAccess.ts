export type UserRole = 'ADMIN' | 'MANAGER' | 'RECEPTIONIST' | 'HOUSEKEEPING';

export type PermissionId =
  | 'dashboard'
  | 'bookings'
  | 'rooms'
  | 'messages'
  | 'housekeeping'
  | 'inventory'
  | 'calendar'
  | 'guests'
  | 'financials'
  | 'reviews'
  | 'concierge'
  | 'users'
  | 'settings';

const PERMISSIONS_KEY = 'laflo:userPermissions';
const SUPER_ADMIN_KEY = 'laflo:superAdmins';
const USER_TITLES_KEY = 'laflo:userTitles';

const permissionOptions: { id: PermissionId; label: string }[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'bookings', label: 'Reservations' },
  { id: 'rooms', label: 'Rooms' },
  { id: 'messages', label: 'Messages' },
  { id: 'housekeeping', label: 'Housekeeping' },
  { id: 'inventory', label: 'Inventory' },
  { id: 'calendar', label: 'Calendar' },
  { id: 'guests', label: 'Guests' },
  { id: 'financials', label: 'Financials' },
  { id: 'reviews', label: 'Reviews' },
  { id: 'concierge', label: 'Concierge' },
  { id: 'users', label: 'Users' },
  { id: 'settings', label: 'Settings' },
];

const defaultPermissions: Record<UserRole, PermissionId[]> = {
  ADMIN: permissionOptions.map((option) => option.id),
  MANAGER: [
    'dashboard',
    'bookings',
    'rooms',
    'messages',
    'housekeeping',
    'inventory',
    'calendar',
    'guests',
    'financials',
    'reviews',
    'concierge',
    'settings',
  ],
  RECEPTIONIST: [
    'dashboard',
    'bookings',
    'rooms',
    'messages',
    'calendar',
    'guests',
    'financials',
  ],
  HOUSEKEEPING: ['dashboard', 'rooms', 'housekeeping', 'calendar', 'messages'],
};

const loadStorage = <T>(key: string, fallback: T): T => {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
};

const saveStorage = <T>(key: string, value: T) => {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(value));
};

export const getPermissionOptions = () => permissionOptions;

/**
 * Get EXPLICIT user permissions - from backend modulePermissions or localStorage ONLY (no role defaults)
 * Use this for enforcing access control based on what admin has explicitly granted
 * @param userId - User ID  
 * @param backendPermissions - Module permissions from backend (from user.modulePermissions)
 */
export const getExplicitPermissions = (
  userId?: string,
  backendPermissions?: PermissionId[]
): PermissionId[] => {
  // If backend provides permissions, use those (source of truth)
  if (backendPermissions && backendPermissions.length > 0) {
    return backendPermissions;
  }
  
  // Check local storage for admin-set permissions
  if (!userId) return [];
  const stored = loadStorage<Record<string, PermissionId[]>>(PERMISSIONS_KEY, {});
  return stored[userId] || [];
};

/**
 * Get user permissions - prefers backend modulePermissions, falls back to local storage, then role defaults
 * @param userId - User ID
 * @param role - User role for default permissions
 * @param backendPermissions - Module permissions from backend (from user.modulePermissions)
 */
export const getUserPermissions = (
  userId?: string,
  role?: UserRole,
  backendPermissions?: PermissionId[]
): PermissionId[] => {
  // If backend provides permissions, use those (source of truth)
  if (backendPermissions && backendPermissions.length > 0) {
    return backendPermissions;
  }
  
  // Fallback to local storage for backwards compatibility
  if (!userId) return role ? defaultPermissions[role] : [];
  const stored = loadStorage<Record<string, PermissionId[]>>(PERMISSIONS_KEY, {});
  return stored[userId] || (role ? defaultPermissions[role] : []);
};

/**
 * Check if user has access to a specific module
 */
export const hasModuleAccess = (
  permission: PermissionId,
  userId?: string,
  role?: UserRole,
  backendPermissions?: PermissionId[]
): boolean => {
  const permissions = getUserPermissions(userId, role, backendPermissions);
  return permissions.includes(permission);
};

export const setUserPermissions = (userId: string, permissions: PermissionId[]) => {
  const stored = loadStorage<Record<string, PermissionId[]>>(PERMISSIONS_KEY, {});
  stored[userId] = permissions;
  saveStorage(PERMISSIONS_KEY, stored);
};

export const getUserTitles = (): Record<string, string> =>
  loadStorage<Record<string, string>>(USER_TITLES_KEY, {});

export const setUserTitle = (userId: string, title: string) => {
  const titles = loadStorage<Record<string, string>>(USER_TITLES_KEY, {});
  if (title.trim()) {
    titles[userId] = title.trim();
  } else {
    delete titles[userId];
  }
  saveStorage(USER_TITLES_KEY, titles);
};

export const getSuperAdminIds = (): string[] =>
  loadStorage<string[]>(SUPER_ADMIN_KEY, []);

export const setSuperAdmin = (userId: string, enabled: boolean) => {
  const ids = new Set(getSuperAdminIds());
  if (enabled) {
    ids.add(userId);
  } else {
    ids.delete(userId);
  }
  saveStorage(SUPER_ADMIN_KEY, Array.from(ids));
};

export const isSuperAdminUser = (userId?: string, role?: UserRole) => {
  // If user has ADMIN role, they are always a super admin
  if (role === 'ADMIN') return true;
  // Also check localStorage for explicitly set super admins
  if (!userId) return false;
  return getSuperAdminIds().includes(userId);
};
